import pygame_shaders
from .window import Window
import pygame


class ShaderWindow(Window):

    def __init__(self, size=(840, 720), display_scale=1, resizeable=True):
        # super().__init__(size, display_scale, resizeable)
        pygame.init()
        self.default_size = size
        self.resizeable = resizeable

        self.screen = pygame.display.set_mode(
            size,
            (pygame.RESIZABLE if self.resizeable else 0)
            | pygame.OPENGL
            | pygame.DOUBLEBUF,
        )

        self.display_scale = display_scale


        self.size = self.screen.get_size()
        self.w, self.h = self.size[0] * self.display_scale, self.size[1] * self.display_scale 
        self.display = pygame.Surface(
            (self.w, self.h), pygame.SRCALPHA
        )

        self.screen_shader = pygame_shaders.DefaultScreenShader(self.display)

        self.clock = pygame.time.Clock()
        self.dt = 0

        self.events = {"press": {}, "release": {}}
        self.mouse = {
            "press": [False, False, False],
            "release": [False, False, False],
            "hold": [False, False, False],
            "pos": (0.0, 0.0),
            "rel": (0.0, 0.0),
            "scroll_up": False,
            "scroll_down": False,
        }

    def reset_default_size(self):
        self.screen = pygame.display.set_mode(
            self.default_size,
            (pygame.RESIZABLE if self.resizeable else 0)
            | pygame.OPENGL
            | pygame.DOUBLEBUF,
        )
        self.size =  self.screen.get_size()
        self.w, self.h = self.size[0] * self.display_scale, self.size[1] * self.display_scale 
        self.display = pygame.Surface(
            (self.w, self.h), pygame.SRCALPHA
        )

    def run(self):
        events = self.setup()  # get the key bindings from 'init()' method
        self.switch_events(events)
        while True:
            self.handle_events()
            self.dt = self.clock.tick(120) / 1000
            self.display.fill((0, 0, 0))

            self.update()

            # self.screen.blit(
            #     pygame.transform.scale(self.display, self.screen.get_size())
            # )
            self.screen_shader.render()

            pygame.display.flip()

