import numpy as np
import pygame_shaders
from .window import Window
import pygame


class ShaderWindow(Window):
    def __init__(self, size=(840, 720), display_scale=1, resizeable=True, fullscreen=False):
        # super().__init__(size, display_scale, resizeable)
        pygame.init()

        Window.default_size = np.array(size)
        self.resizeable = resizeable
        self._fullscreen = fullscreen


        self.screen = pygame.display.set_mode(
            size,
            (pygame.RESIZABLE if self.resizeable else 0)
            | pygame.OPENGL
            | pygame.DOUBLEBUF 
            | (pygame.FULLSCREEN if self._fullscreen else 0)
            
        )

        Window.display_scale = display_scale

        Window.size = np.array(self.screen.get_size())
        Window.w, Window.h = Window.size[0] * Window.display_scale, Window.size[1] * Window.display_scale 
        
        self.display = pygame.Surface(
            (Window.w, Window.h), pygame.SRCALPHA
        )

        self.screen_shader = pygame_shaders.DefaultScreenShader(self.display)

        self.clock = pygame.time.Clock()
        self.dt = 0

        self.events = {"press": {}, "release": {}}
        self._sate_resets = {}
        self.mouse = {
            "press": [False, False, False],
            "release": [False, False, False],
            "hold": [False, False, False],
            "pos": (0.0, 0.0),
            "rel": (0.0, 0.0),
            "scroll_up": False,
            "scroll_down": False,
        }

    def reset_default_size(self):
        self.screen = pygame.display.set_mode(
            self.default_size,
            (pygame.RESIZABLE if self.resizeable else 0)
            | pygame.OPENGL
            | pygame.DOUBLEBUF
            | (pygame.FULLSCREEN if self._fullscreen else 0)
        )
        Window.size = np.array(self.screen.get_size())
        Window.w, Window.h = Window.size[0] * Window.display_scale, Window.size[1] * Window.display_scale 
        self.display = pygame.Surface(
            (Window.w, Window.h), pygame.SRCALPHA
        )
        self.screen_shader = pygame_shaders.DefaultScreenShader(self.display)
    
    @property
    def fullscreen(self):
        return self._fullscreen
    
    @fullscreen.setter
    def fullscreen(self, v):
        self._fullscreen = v
        self.reset_default_size()
        



    def run(self):
        events = self.setup()  # get the key bindings from 'init()' method
        self.switch_events(events)
        while True:
            self.handle_events()
            self.dt = self.clock.tick(120) / 1000
            self.display.fill((0, 0, 0))

            self._reset_states()
            self.update()


            # self.screen.blit(
            #     pygame.transform.scale(self.display, self.screen.get_size())
            # )
            self.screen_shader.render()

            pygame.display.flip()

