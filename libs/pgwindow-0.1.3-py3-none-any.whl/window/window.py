import numpy as np
import pygame
from typing import Literal
from abc import ABC, abstractmethod


"""
Example Usage

class App(Window):
    def setup(self):
        self.font = pygame.font.SysFont("Arial", 32)
        self.count = 0
        return {"press": {pygame.K_r: lambda: print("Szija")}} 
        # if the callback returns True, it will reset the events

    def update(self):
        if self.get_event(pygame.K_SPACE):
            self.count += 1

        text = self.font.render(str(self.count), True, (255, 255, 255))
        self.display.blit(text, (200, 200))


if __name__ == "__main__":
    App().run()

"""


class Window(ABC):
    size = np.array((840, 720), np.float32)
    display_scale = 1
    default_size = size
    w, h = 840, 720
    def __init__(self, size=(840, 720), display_scale=1, resizeable=True):
        pygame.init()

        Window.default_size = np.array(size, np.float32)
        self.resizeable = resizeable
        
        
        self.screen = pygame.display.set_mode(
            size, (pygame.RESIZABLE if self.resizeable else 0)
        )
        
        Window.display_scale = display_scale

        Window.size = np.array(self.screen.get_size())
        Window.w, Window.h = Window.size[0] * Window.display_scale, Window.size[1] * Window.display_scale 
        
        self.display = pygame.Surface(
            (Window.w, Window.h), pygame.SRCALPHA
        )
        
        self.clock = pygame.time.Clock()
        self.dt = 0

        self.events = {"press": {}, "release": {}, "hold" : {}}
        self._sate_resets = {}

        self.mouse = {
            "press": [False, False, False],
            "release": [False, False, False],
            "hold": [False, False, False],
            "pos": (0.0, 0.0),
            "rel": (0.0, 0.0),
            "scroll_up": False,
            "scroll_down": False,
        }

    def reset_default_size(self):
        self.screen = pygame.display.set_mode(
            self.default_size, (pygame.RESIZABLE if self.resizeable else 0)
        )
        Window.size =  self.screen.get_size()
        Window.w, Window.h = Window.size[0] * Window.display_scale, Window.size[1] * Window.display_scale 
        self.display = pygame.Surface(
            (Window.w, Window.h), pygame.SRCALPHA
        )
    
    def handle_events(self):
        self.mouse["press"] = [False, False, False]
        self.mouse["release"] = [False, False, False]
        self.mouse["scroll_up"] = False
        self.mouse["scroll_down"] = False

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    self.mouse["press"][0] = True
                    self.mouse["hold"][0] = True
                if event.button == 2:
                    self.mouse["press"][1] = True
                    self.mouse["hold"][1] = True
                if event.button == 3:
                    self.mouse["press"][2] = True
                    self.mouse["hold"][2] = True
            if event.type == pygame.MOUSEBUTTONUP:
                if event.button == 1:
                    self.mouse["release"][0] = True
                    self.mouse["hold"][0] = False
                if event.button == 2:
                    self.mouse["release"][1] = True
                    self.mouse["hold"][1] = False
                if event.button == 3:
                    self.mouse["release"][2] = True
                    self.mouse["hold"][2] = False
                if event.button == 4:
                    self.mouse["scroll_down"] = True
                if event.button == 5:
                    self.mouse["scroll_up"] = True
            if event.type == pygame.KEYDOWN:
                for e in self.events["press"]:
                    if event.key == e:
                        #if self.events["press"][e][0](): break # reset the event loop
                        self.events["press"][e][1] = True
                        self.events["press"][e][0]()
                  
                for e in self.events["hold"]:
                    if e in self.events["hold"]:
                        self.events["hold"][e][1] = True

            if event.type == pygame.KEYUP:
                for e in self.events["release"]:
                    if event.key == e:
                        self.events["release"][e][1] = True
                        self.events["release"][e][0]()
                        
                    for e in self.events["hold"]:
                        if e in self.events["hold"]:
                            self.events["hold"][e][1] = False
            
        for event in self.events["hold"]:
            if self.events["hold"][event][1]:
                self.events["hold"][event][0]()
        self._handle_mouse_events()
    
    def _handle_mouse_events(self):
        mx, my = pygame.mouse.get_pos()
        self.mouse["pos"] = (mx * Window.display_scale, my * Window.display_scale)
        self.mouse["rel"] = pygame.mouse.get_rel()

    def get_event(self, event, mode: Literal["press", "release", "hold"] = "press"):
        if not (self.events[mode].get(event)):
            self.events[mode][event] = [lambda: ..., False]
        if self.events[mode][event][1]:
            if mode not in self._sate_resets: self._sate_resets[mode] = []
            if event not in self._sate_resets[mode]: self._sate_resets[mode].append(event)
        return self.events[mode][event][1]
    
    def _reset_states(self):
        states = self._sate_resets.copy()
        for mode in states:
            if len(states[mode]) == 0: self._sate_resets.pop(mode)
            for i, event in enumerate(states[mode]):
                self.events[mode][event][1] = False
                self._sate_resets[mode].pop(i)
        


    @abstractmethod
    def setup(self):
        """Called once when the window is created (like __init__).
           returns a dict of input keys {<action> : {<key> : <func>}}
        """
        pass

    @abstractmethod
    def update(self):
        """Called repeatedly in the main loop."""
        pass

    def switch_events(self, new_events : dict):
        events = new_events.copy()
        for e in events:
            # The key state DOES NOT update via handle_events
            # the state updated via 'get_event()' for better preformance
            events[e] = {i: [events[e][i], False] for i in events[e]}
        self.events.update(events)
        self._sate_resets = {}

    def run(self):
        events = self.setup()  # get the key bindings from 'init()' method
        self.switch_events(events)
        #print(events)
        # for e in events:
        #     # The key state DOES NOT update via handle_events
        #     # the state updated via 'get_event()' for better preformance
        #     events[e] = {i: [events[e][i], False] for i in events[e]}
        # self.update_events(events)
        while True:
            self.handle_events()
            self.dt = self.clock.tick(120) / 1000
            self.display.fill((0, 0, 0))

            self._reset_states()
            self.update()

            self.screen.blit(
                pygame.transform.scale(self.display, self.screen.get_size())
            )
            pygame.display.update()
